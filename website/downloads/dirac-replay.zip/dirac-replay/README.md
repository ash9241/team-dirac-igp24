# Reproduce one Team Dirac polynomial

This package reconstructs one degree-24 polynomial using Python 3 and PARI/GP.
It requires no credentials or network access once those tools are installed.

Run:

    python3 replay_example.py --gp /path/to/gp

The replay takes the quotient polynomial from the recorded degree-24 source,
constructs the degree-66 pair-product resolvent, factors it over Q, selects the
unique degree-12 factor h, and forms h(x^2). It verifies the exact coefficients,
SHA-256, degree 24, irreducibility, and 20 real roots.

The group label 24T15308 is supported separately by the archived official receipt
and the local action certificate in evidence/worked_example.json. This script
DOES NOT rerun or replace exact Galois-group identification in Magma.

The included result was replayed for the September 8, 2026 publication audit.
Submission timestamps are historical. Shared credit can change after acceptance.

Research: Durgesh Kumar and Aishwarya Das, Team Dirac.
